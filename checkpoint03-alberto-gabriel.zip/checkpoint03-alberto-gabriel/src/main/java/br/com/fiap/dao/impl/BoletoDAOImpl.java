package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.entity.Boleto;

public class BoletoDAOImpl extends HibernateGenericDAO<Boleto, Long>  {

	private static BoletoDAOImpl instance = null;

	public static BoletoDAOImpl getInstance() {
		if (instance == null) {
			instance = new BoletoDAOImpl();
		}
		
		return instance;
	}

	private BoletoDAOImpl() {
		super(Boleto.class);
	}

	@Override
	public List<Boleto> listar(EntityManager entityManager) {
		TypedQuery<Boleto> consulta = entityManager.createNamedQuery("Boleto.listar", Boleto.class);
		
		return consulta.getResultList();
	}
	

	
}
