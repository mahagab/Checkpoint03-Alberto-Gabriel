package br.com.fiap.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tb_ItemPedido")
@SequenceGenerator(name = "itempedido", sequenceName = "SQ_TB_ITEM_PEDIDO", allocationSize = 1)

public class ItemPedido implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public ItemPedido(int quantidade) {
	
		this.quantidade = quantidade;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "itempedido")
	private Long id;
	
	@Column(name = "nr_quantidade", length = 8, nullable = false)
	private int quantidade;

	@ManyToOne
	@JoinColumn(name = "pedido_id")
	private Pedido pedido;
	public Long getId() {
		return id;
	}
	
	@ManyToOne
	@JoinColumn(name = "pedido_id")
	private Produto produto;
	public Long getIdProduto() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	@Override
	public String toString() {
		
		return "\nQuantidade de Produtos: " + this.getQuantidade();

	}
	

}
