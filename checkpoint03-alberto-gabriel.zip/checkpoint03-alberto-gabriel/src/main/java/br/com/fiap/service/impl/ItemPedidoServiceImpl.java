package br.com.fiap.service.impl;

import java.util.List;

import br.com.fiap.dao.impl.ItemPedidoDAOImpl;
import br.com.fiap.entity.ItemPedido;
import br.com.fiap.jpa.service.GenericService;

public class ItemPedidoServiceImpl extends GenericService<ItemPedido, Long> {
	
private static ItemPedidoServiceImpl instance = null;
	
	private ItemPedidoDAOImpl ItempedidoDAO;

	
	private ItemPedidoServiceImpl() {
		ItempedidoDAO = ItemPedidoDAOImpl.getInstance();

	}
	
	public static ItemPedidoServiceImpl getInstance() {
		
		if (instance == null) {
			instance = new ItemPedidoServiceImpl();
		}
		
		return instance;
	}
	
	@Override
	public void inserir(ItemPedido Itempedido) {
		try {
			ItempedidoDAO.salvar(Itempedido, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
	}
	
	
	@Override
	public void atualizar(ItemPedido Itempedido) {
		try {
			ItempedidoDAO.atualizar(Itempedido, getEntityManager());
		} catch (Exception e) {
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public void remover(Long id) {
		try {
			ItempedidoDAO.remover(id, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public ItemPedido obter(Long id) {
		ItemPedido Itempedido = null;
		
		try {
			Itempedido = ItempedidoDAO.obterPorId(id, getEntityManager());
		} catch (Exception e) {
		} finally {
			closeEntityManager();
		}
		
		return Itempedido;
	}

	@Override
	public List<ItemPedido> listar() {
		List<ItemPedido> pedidos = null;
		
		try {
			pedidos = ItempedidoDAO.listar(getEntityManager());
		} catch (Exception e) {
		} finally {
			closeEntityManager();
		}
		
		return pedidos;
	}
	

}
