package br.com.fiap;

import br.com.fiap.service.impl.BoletoServiceImpl;
import br.com.fiap.service.impl.ItemPedidoServiceImpl;
import br.com.fiap.service.impl.PedidoServiceImpl;
import br.com.fiap.service.impl.ProdutoServiceImpl;

public class App {

	public static void main(String[] args) {
	
		BoletoServiceImpl boletoService = BoletoServiceImpl.getInstance();
		ItemPedidoServiceImpl itempedidoService = ItemPedidoServiceImpl.getInstance();
		PedidoServiceImpl pedidoService = PedidoServiceImpl.getInstance();
		ProdutoServiceImpl produtoService = ProdutoServiceImpl.getInstance();
		
		System.out.println("============ Listar pedidos associados ao cliente ==============");
		
		pedidoService.listarPorCpf("111.111.111-11").forEach(System.out::println);

		
		

	
	}
}
