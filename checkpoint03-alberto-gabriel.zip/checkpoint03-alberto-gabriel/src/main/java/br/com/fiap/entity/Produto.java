package br.com.fiap.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "tb_produto")
@SequenceGenerator(name = "produto", sequenceName = "SQ_TB_PRODUTO", allocationSize = 1)

public class Produto implements Serializable {

	private static final long serialVersionUID = -1606933813055933311L;
	
	public Produto(String nome, double valor) {
		this.nome = nome;
		this.valor = valor;
	}
	
	@OneToMany(mappedBy = "produtos")
	private List<ItemPedido> produtos;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "produto")
	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	@Column(name = "nm_produto")
	private String nome;

	@Column(name = "valor")
	private double valor;
	
	
	@Override
	public String toString() {
		
		return "\nNome Produto: " + this.getNome() 
			+ "\nValor: " + this.getValor();
	}


}
