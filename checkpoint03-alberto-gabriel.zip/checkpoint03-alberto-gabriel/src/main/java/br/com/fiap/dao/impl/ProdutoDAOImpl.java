package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import br.com.fiap.entity.Produto;

public class ProdutoDAOImpl extends HibernateGenericDAO<Produto, Long>  {

	
	private static ProdutoDAOImpl instance = null;


	public static ProdutoDAOImpl getInstance() {
		if (instance == null) {
			instance = new ProdutoDAOImpl();
		}
		
		return instance;
	}

	private ProdutoDAOImpl() {
		super(Produto.class);
	}


	@Override
	public List<Produto> listar(EntityManager entityManager) {
		TypedQuery<Produto> consulta = entityManager.createNamedQuery("Produto.listar", Produto.class);
		
		return consulta.getResultList();
	}

}
