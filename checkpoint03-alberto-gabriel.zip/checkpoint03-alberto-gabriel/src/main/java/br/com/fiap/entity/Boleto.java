package br.com.fiap.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "tb_boleto")
@SequenceGenerator(name = "boleto", sequenceName = "SQ_TB_BOLETO", allocationSize = 1)

public class Boleto implements Serializable{

	private static final long serialVersionUID = 3137859033727197761L;
	
	
	public Boleto(int nossoNumero, LocalDate dtVencimento, int valor,int codBarras) {
		this.dataVencimento = dtVencimento;
		this.nossoNumero = nossoNumero;
		this.valor = valor;
		this.codBarras = codBarras;
	}
	
	@OneToOne(mappedBy = "boleto", cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Pedido pedido;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "boleto")
	private Long id;
	
	@Column(name = "nm_nossoNumero", length = 80, nullable = false)
	private int nossoNumero;
	
	@Column(name = "dt_vencimento")
	private LocalDate dataVencimento;

	@Column(name = "valor")
	private double valor;
	
	@Column(name = "nm_codBarras", length = 13, nullable = false)
	private int codBarras;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNossoNumero() {
		return nossoNumero;
	}

	public void setNossoNumero(int nossoNumero) {
		this.nossoNumero = nossoNumero;
	}

	public LocalDate getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(LocalDate dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public int getCodBarras() {
		return codBarras;
	}

	public void setCodBarras(int codBarras) {
		this.codBarras = codBarras;
	}
	
	@Override
	public String toString() {
		
		return "\nCodigo de Barras: " + this.getCodBarras() 
			+ "\nValor: " + this.getValor()
			+ "\nData de Vencimento: " + this.getDataVencimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
			+ "\nNosso Numero: " + this.getNossoNumero();
	}

	
}
