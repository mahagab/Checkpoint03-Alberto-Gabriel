package br.com.fiap.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tb_pedido")
@SequenceGenerator(name = "pedido", sequenceName = "SQ_TB_PEDIDO", allocationSize = 1)

public class Pedido implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public Pedido(int numeroPedido, String cpf, double valorTotal) {
		this.cpf = cpf;
		this.numeroPedido = numeroPedido;
		this.valorTotal = valorTotal;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pedido")
	private Long id;
	
	@Column(name = "nr_numeroPedido", length = 20, nullable = false)
	private int numeroPedido;
	
	@Column(name = "dt_cpf")
	private String cpf;

	@Column(name = "valorTotal")
	private double valorTotal;
	
	@OneToMany(mappedBy = "pedido")
	private List<ItemPedido> item;
	
	@OneToOne(mappedBy = "pedido", cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Boleto boleto;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(int numeroPedido) {
		this.numeroPedido = numeroPedido;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	@Override
	public String toString() {
		
		return "\nCpf do Cliente: " + this.getCpf() 
			+ "\nValor Total: " + this.getValorTotal()
			+ "\nData de Vencimento: " + this.getNumeroPedido();
	}


}
