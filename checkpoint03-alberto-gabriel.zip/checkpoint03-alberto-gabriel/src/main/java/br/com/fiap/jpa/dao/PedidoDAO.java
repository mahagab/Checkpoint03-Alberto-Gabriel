package br.com.fiap.jpa.dao;

import br.com.fiap.entity.Pedido;

public interface PedidoDAO extends GenericDAO<Pedido, Long> {

}
